public interface AddressValidator {
  public boolean isValidAddress(String inp_address,
      String inp_zip, String inp_state);
}// end of class


