public class Directory {

  private String name;

  public Directory(String n) {
    name = n;
  }
}
