from tkinter import *
from tkinter import ttk
from Composite import * 

class ComponentsUI(Toplevel):
    CREATE_FILE = "Create file"
    CREATE_DIR = "Create dir"
    ADD_COMPONENT = "Add to component"
    GET_SIZE = "Get size"
    EXIT = "Exit"
    
    def __init__(self, master):
        Toplevel.__init__(self,master)

        self.__lblNameFile = Label(self,text="Name file: ")
        self.__lblSizeFile = Label(self,text="Size file: ")
        self.__lblNameDir = Label(self,text="Name dir: ")
        self.__lblSizeText = Label(self,text="Size: ")
        self.__lblSizeComponent = Label(self)
        self.__lblInfo = Label(self)

        self.__txtNameFile = Entry(self)
        self.__txtSizeFile = Entry(self)
        self.__txtNameDir = Entry(self)
        
        self.__cmbDirList = ttk.Combobox(self, state="readonly")
        
        self.__lstComponents = Listbox(self)

        self.__btnCreateFile = Button(self,text=ComponentsUI.CREATE_FILE)
        self.__btnCreateDir = Button(self,text=ComponentsUI.CREATE_DIR)
        self.__btnAddComponent = Button(self,text=ComponentsUI.ADD_COMPONENT)
        self.__btnGetSize = Button(self,text=ComponentsUI.GET_SIZE)
        self.__btnExit = Button(self,text=ComponentsUI.EXIT)

        self.__lblNameFile.grid(row=1,column=1,pady=10)
        self.__txtNameFile.grid(row=1,column=2,pady=10)
        self.__lblSizeFile.grid(row=1,column=3,pady=10)
        self.__txtSizeFile.grid(row=1,column=4,pady=10)
        self.__btnCreateFile.grid(row=1,column=5,padx=10,pady=10)
        self.__lblNameDir.grid(row=2,column=3,pady=10)
        self.__txtNameDir.grid(row=2,column=4,pady=10)
        self.__btnCreateDir.grid(row=2,column=5,padx=10,pady=10)
        self.__cmbDirList.grid(row=3,column=2,padx=10, pady=10)
        self.__lstComponents.grid(row=3,column=3,pady=10)
        self.__btnAddComponent.grid(row=3,column=4,pady=10)
        self.__lblInfo.grid(row=3,column=5,padx=10,pady=10)
        self.__btnGetSize.grid(row=4,column=3,pady=10)
        self.__lblSizeText.grid(row=4,column=4,pady=10)
        self.__lblSizeComponent.grid(row=4,column=5,padx=10,pady=10)
        self.__btnExit.grid(row=5,column=4,pady=10)
    def getTxtNameFile(self):
        return self.__txtNameFile
    def getTxtSizeFile(self):
        return self.__txtSizeFile
    def getTxtNameDir(self):
        return self.__txtNameDir
    def getCmbDirList(self):
        return self.__cmbDirList
    def getLstComponents(self):
        return self.__lstComponents
    def getBtnCreateFile(self):
        return self.__btnCreateFile
    def getBtnCreateDir(self):
        return self.__btnCreateDir
    def getBtnAddComponent(self):
        return self.__btnAddComponent
    def getBtnGetSize(self):
        return self.__btnGetSize
    def getBtnExit(self):
        return self.__btnExit
    def getBtnLblSizeComponent(self):
        return self.__lblSizeComponent
    def addToCmb(self, element):
        self.__cmbDirList["values"]=element
        self.__cmbDirList.current(0)
    def addToList(self, element):
        self.__lstComponents.insert(END,element)
        self.clean()
    def setSize(self, size):
        self.__lblSizeComponent.config(text=size)
    def clean(self):
        self.__txtNameFile.delete(0,END)
        self.__txtSizeFile.delete(0,END)
        self.__txtNameDir.delete(0,END)
        self.__lblSizeComponent.configure(text="")
        self.__lblInfo.configure(text="")
    def setInfo(self, info):
        self.__lblInfo.configure(text=info)
#End of class

class ButtonHandler():
    FILE="File"
    DIR="Dir"
    def __init__(self,root):
        self.__root=root
        self.__frame=ComponentsUI(root)
        self.__frame.getBtnCreateFile().configure(command=self.eventCreateFile)
        self.__frame.getBtnCreateDir().configure(command=self.eventCreateDir)
        self.__frame.getBtnAddComponent().configure(command=self.eventAddComponent)
        self.__frame.getBtnGetSize().configure(command=self.eventGetSize)
        self.__frame.getBtnExit().configure(command=self.eventExit)

        self.__fileList = []
        self.__dirList = []
        self.__componentList=[]
    def eventCreateFile(self):
        name = self.__frame.getTxtNameFile().get()
        size = self.__frame.getTxtSizeFile().get()
        file = FileComponent(name,size)
        self.__fileList.append(file)
        self.updateList(ButtonHandler.FILE)
    def eventCreateDir(self):
        name = self.__frame.getTxtNameDir().get()
        dirC = DirComponent(name)
        self.__dirList.append(dirC)
        self.updateList(ButtonHandler.DIR)
        self.updateCombobox()
    def eventAddComponent(self):
        self.__frame.clean()
        currentComponent = self.__frame.getLstComponents().curselection()[0]
        currentDir = self.__frame.getCmbDirList().current()
        component = self.__componentList[currentComponent]
        dirC = self.__dirList[currentDir]
        try:
            if dirC is component:
                self.__frame.setInfo("Error")
            else:
                dirC.addComponent(component)
                self.__frame.setInfo("Successfull")
        except CompositeException:
            self.__frame.setInfo("Method not supported")
    def eventGetSize(self):
        self.__frame.clean()
        current = self.__frame.getLstComponents().curselection()[0]
        try:
            size = self.__componentList[current].getComponentSize()
            self.__frame.setSize(size)
        except RecursionError:
            self.__frame.setSize("Recursion Error")
    def eventExit(self):
        self.__frame.destroy()
        self.__root.destroy()
    def updateList(self,typeC):
        if typeC==ButtonHandler.FILE:
            self.__componentList.append(self.__fileList[-1])
        elif typeC==ButtonHandler.DIR:
            self.__componentList.append(self.__dirList[-1])
        self.__frame.addToList(typeC+": "+str(self.__componentList[-1]))
    def updateCombobox(self):
        self.__frame.addToCmb(self.__dirList)
#End of class

if __name__=="__main__":
    root = Tk()
    root.withdraw()
    app = ButtonHandler(root)
    root.mainloop()
    #app.frame.mainloop()
    #root.destroy()
