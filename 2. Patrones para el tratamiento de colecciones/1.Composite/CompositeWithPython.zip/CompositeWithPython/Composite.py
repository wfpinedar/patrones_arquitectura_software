import abc

class CompositeException(Exception):
    def __init__(self, mensaje):
        self.mensaje=mensaje
#End of class
class FileSystemComponent:
    __metaclass__ = abc.ABCMeta
    def __init__(self, name):
        self._name=name
    def addComponent(self,component):
        raise CompositeException()
    def getComponent(componentNum):
        raise CompositeException()
    def getComponentSize(self):
        raise NotImplementedError()
    def getSearchUI(self):
        return self._searchUI
    def getName(self):
        return self._name
    def __str__(self):
        return self._name
#End of class
class FileComponent(FileSystemComponent):
    def __init__(self,name,size):
        FileSystemComponent.__init__(self,name)
        self.__size=int(size)
    def getComponentSize(self):
        return self.__size
#End of class
class DirComponent(FileSystemComponent):
    def __init__(self, name):
        self.__dirContents=[]
        FileSystemComponent.__init__(self,name)
    def addComponent(self, fc):
        self.__dirContents.append(fc)
    def getComponent(self,location):
        return self.__dirContents.get(location)
    def getComponentSize(self):
        sizeOfAllFiles=0
        for component in self.__dirContents:
            sizeOfAllFiles = sizeOfAllFiles + component.getComponentSize()
        return sizeOfAllFiles
#End of class
