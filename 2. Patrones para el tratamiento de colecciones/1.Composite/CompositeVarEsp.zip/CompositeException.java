import java.util.*;

public class CompositeException extends Exception {

  public CompositeException(String msg) {
    super(msg);
  }
} // End of class

