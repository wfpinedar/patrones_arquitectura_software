public interface Logger {

  public void log(String file,String msg);

}
