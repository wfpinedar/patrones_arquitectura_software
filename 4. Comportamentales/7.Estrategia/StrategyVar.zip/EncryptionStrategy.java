public interface EncryptionStrategy {
  public String encrypt(String inputData);
}
