public interface Observer {
  public void refreshData(Observable subject);
}
