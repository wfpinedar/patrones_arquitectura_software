public interface Expression {
  public int evaluate(Context c);
}
