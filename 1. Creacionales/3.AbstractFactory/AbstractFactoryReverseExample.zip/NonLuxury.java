public interface NonLuxury {
  public String getNLName();
  public String getNLFeatures();

} // End of class


