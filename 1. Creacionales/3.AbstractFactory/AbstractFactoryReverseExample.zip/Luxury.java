public interface Luxury {
  public String getLuxuryName();
  public String getLuxuryFeatures();

} // End of class


