from Logger import *

class ConsoleLogger(Logger):
    
    def log(self, msg):
        print(msg);

    
